Project: 'Netwerken - 9 - Lab 2 - Routing' created on 2020-11-09
Author: Gregory Bers <gregorybers@epiecs.be>

Basis routing lab met interfaces en nat ingesteld